<?php
$conflicted_pages = array(
	"mashup" => array(
		"About Us",
		"Home",
	),
);